import UserModel from '../models/user.js';
import { db } from "../config/firebase.js";
import {updateDailyActivity} from "../utils/activityService.js"
import { handleDailyReset } from '../utils/resetService.js'; 
import DailyActivityModel from '../models/dailyActivity.js';


export const getUserProfile = async (req, res) => {
    try {
        const { uid } = req.params; 
        if (!uid) {
            return res.status(400).json({ error: 'User UID is required.' });
        }
        const user = await UserModel.findOne({ uid: uid });
        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }
        console.log(`user found successfully ${user} `);
        const updatedUser = await handleDailyReset(user);
        console.log(`User after Daily Reset ${updatedUser}`);
        res.status(200).json(updatedUser || user);

    } catch (error) {
        console.error("Error fetching user profile:", error);
        res.status(500).json({ error: 'An unexpected server error occurred.' });
    }
};

export const updateUserProfile = async (req, res) => {
    try {
        const { uid } = req.params;
        // We exclude fields that shouldn't be updated directly via this route
        const { email, stats, rewards, multipliers, coins, ...updateData } = req.body;

        if (!uid) {
            return res.status(400).json({ error: 'User UID is required.' });
        }

        const updatedUser = await UserModel.findOneAndUpdate(
            { uid: uid },
            { $set: updateData },
            { new: true } // This option returns the updated document
        );

        if (!updatedUser) {
            return res.status(404).json({ error: 'User not found.' });
        }

        console.log(`[updateUserProfile] Successfully updated profile for user ${uid}`);
        res.status(200).json(updatedUser);

    } catch (error) {
        console.error("Error updating user profile:", error);
        res.status(500).json({ error: 'An unexpected server error occurred.' });
    }
};

export const syncUserSteps = async (req, res) => {
    try {
        const { uid, todaysStepCount } = req.body;
        if (!uid || todaysStepCount === undefined) {
            return res.status(400).json({ error: 'User UID and todaysStepCount are required.' });
        }
        const updatedUser = await UserModel.findOneAndUpdate(
            { uid: uid },
            { $set: { todaysStepCount: todaysStepCount } },
            { new: true } 
        );
        if (!updatedUser) {
            return res.status(404).json({ error: 'User not found.' });
        }
        res.status(200).json({ message: 'Step count synced successfully.', user: updatedUser });

    } catch (error) {
        console.error("Error syncing user steps:", error);
        res.status(500).json({ error: 'An unexpected server error occurred.' });
    }
};

export const getAllUsers = async (req, res) => {
  try {
    const usersSnapshot = await db.collection("users").get();
    const users = usersSnapshot.docs.map(doc => doc.data());
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getUserRewards = async (req, res) => {
    const { uid } = req.params;
    if (!uid) {
        return res.status(400).json({ error: "User UID is required." });
    }

    try {
        const user = await UserModel.findOne({ uid: uid })
            .populate('rewards.Fort rewards.Monument rewards.Legend rewards.Badge');

        if (!user) {
            return res.status(404).json({ error: "User not found." });
        }

        res.status(200).json(user.rewards);

    } catch (error) {
        console.error("Error fetching user rewards:", error);
        res.status(500).json({ error: "An unexpected server error occurred." });
    }
};


export const getActivityHistory = async (req, res) => {
  const { uid } = req.params;
  if (!uid) {
    return res.status(400).json({ error: "User UID is required." });
  }

  try {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setUTCDate(sevenDaysAgo.getUTCDate() - 7);
    sevenDaysAgo.setUTCHours(0, 0, 0, 0);

    const activities = await DailyActivityModel.find({
      uid: uid,
      date: { $gte: sevenDaysAgo }
    })
    .sort({ date: 'asc' }); 

    res.status(200).json(activities);

  } catch (error) {
    console.error("Error fetching activity history:", error);
    res.status(500).json({ error: "An unexpected server error occurred." });
  }
};
